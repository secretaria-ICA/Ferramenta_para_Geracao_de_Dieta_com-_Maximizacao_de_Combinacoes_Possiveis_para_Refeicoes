

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $cpf = $_POST["cpf"];
    $nome = $_POST["nome"];
    $consulta = $_POST["consulta"];
    $qtd = $_POST["qtd"];
    $peso = $_POST["peso"];

    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de insert
$sql = "insert into dieta.tbdietacli
select '".$nome."',".$cpf.", ".$peso." ,".$consulta.", ".$qtd.",id, item,kcal, qtdporcao, categoria, refeicao, dia, date_format(CURRENT_DATE, '%d/%m/%Y') from dieta.tbtempdiasdieta";

    //echo $sql;
   //sleep(15)

    
    //4- Executar a instrução SQL
    if(mysqli_query($con,$sql)) {
        $msg = "Dieta Inserida Para Este Cliente";
    }else{
        $msg = "Erro ao Inserir Dieta para Este Cliente";
    }
    



    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="incluidieta.php"; //redirecionamento em JS
</script>