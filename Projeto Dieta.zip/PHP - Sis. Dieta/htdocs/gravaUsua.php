

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $matricula = $_POST["matricula"];
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];
    $perfil = $_POST["perfil"];
    $ativo = $_POST["ativo"];
    


    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de insert
    $sql = "insert into tbusuario (matricula,nome,senha,perfil,ativo) values(".$matricula.",'".$nome."','".md5($senha)."',".$perfil.",".$ativo.")";
   //echo $sql;  
   //sleep(15)
   

    
    //4- Executar a instrução SQL
    if(mysqli_query($con,$sql)) {
        $msg = "Usuário Inserido com sucesso!";
    }else{
        $msg = "Erro ao gravar o Usuário!";
    }
    


    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="caduser.php"; //redirecionamento em JS
</script>