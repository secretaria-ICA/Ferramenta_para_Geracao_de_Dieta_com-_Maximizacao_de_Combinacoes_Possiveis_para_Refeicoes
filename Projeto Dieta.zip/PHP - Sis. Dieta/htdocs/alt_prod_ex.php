
<?php 
include_once "conexao.php";
    include_once "autenticacao.php";
    
            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:cadprod.php");
              }if($_SESSION["perfil"] == "2"){                
                include_once ("location:cadprod.php");
            }if($_SESSION["perfil"] == "3"){                
                header("location:home2.php");
              }
            ?>

            <div>Olá: <?php echo ($_SESSION["nome"])," ",($_SESSION["matricula"]);?> Seja Bem Vindo.
        

            <?php
            //isset() -> Verifica se a variável existe e está diferente de null
            if(isset($_GET["codigo"])){

                $codigo = $_GET["codigo"];

                $con = mysqli_connect("localhost","root","1234","dieta");

                $sql = "select * from tbproduto where codigo='$codigo' or nome like '%$codigo%' limit 1";
                //echo $sql;

                //Executar a consulta
                $result = mysqli_query($con,$sql);                
                //var_dump($result); mostra o conteúdo de uma variável

                if(mysqli_num_rows($result) > 0){
                    //echo "ok";

                    
                }
              }
                    ?>

<!DOCTYPE html>

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<script src="/vue/vuev2.6.11.js"></script>		
	<script type="text/javascript" src="/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/jquery/jquery.mask.min.js"></script>	
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
        <h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
			<a href="home.php">Página Inicial</a>
            <a href="cadprod.php">Cadastro Produto</a>
		</div>
		
	</div>	

	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>Alteração / Exclusão de Produto</h2>
				

			</div><!--// fechamento postagem-->
			<form class="cad-prestador" id="app" @submit="checkForm" action="alt_prod_ex.php" method="GET">
			<!-- abertura postagem-->
			<div class="cadastro">

		
					
						<label for="codigo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pesquise pelo Codigo ou Nome do Produto<input class="procurarb" type="image" src="img/buscar.png" width="25"></label>
                        <center><input class="input-cad-prestador" type="text" v-model="codigo" name="codigo" placeholder="Codigo do Produto ou Nome do Produto"  id="codigo" maxlength="10" onkeypress="return ApenasNumeros(event,this);"></center>
			


                                        </form>

                      <form class="cad-prestador" action="atualiza_produto.php" method="POST">

                    <?php
                    // finaliza o loop que vai mostrar os dados
                    while($row = mysqli_fetch_array($result)){?>


              <input type="hidden" value="<?php echo $row["codigo"];?>" name="codigo" id="codigo">
              <input type="hidden" value="<?php echo $row["nome"];?>" name="codigo" id="codigo">


                        <label for="codigoprod">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Codigo do Produto</label>
						<center><input class="input-cad-prestador" type="text" name="codigoprod" value="<?php echo $row["codigo"];?>" placeholder="Codigo do Produto"  id="proddesc" maxlength="10" onkeypress="return ApenasNumeros(event,this);"></center>
                    
						<label for="produto">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Descrição do Produto</label>
						<center><input class="input-cad-prestador" type="text" name="proddesc" value="<?php echo $row["nome"];?>" placeholder="Descrição do Produto"  id="proddesc" maxlength="35" onkeypress="return ApenasLetras(event,this);"></center>
					

					
						<label for="kcal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kcal do Produto</label>
					<center><input class="input-cad-prestador" type="number" inputmode="numeric" step="0.01" value="<?php echo $row["kcal"];?>" name="kcal" placeholder="Kcal do Produto"  id="kcal" maxlength="11" onkeypress="return ApenasNumerosPonto(event,this);"></center>
					

					
						<label for="quantidade">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quantidade Porção</label>
					<center><input class="input-cad-prestador" type="number" inputmode="numeric" name="quantidade" value = "<?php echo $row["quantidade"];?>" placeholder="Quantidade Porção"  id="quantidade" maxlength="11" onkeypress="return ApenasNumerosPonto(event,this);"></center>
					
                    
                    
                    <center><label for="tipo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categoria do Produto</label>
                    <select class="input-cad-prestador" name="tipo" id="tipo">
                    <option><?php echo $row["categoria"];?></option>
                    <option value="Carboidrato">Carboidrato</option>
                    <option value="Proteina">Proteina</option>
                    </select></center>
			

					
						<label for="cafe">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Produto Incluido no café da Dieta?</label>
					<center><input class="input-cad-prestador" type="number" value="<?php echo $row["cafe"];?>" inputmode="numeric" name="cafe" placeholder="0 se não - 1 se sim"  id="cafe" maxlength="1" onkeypress="return ApenasNumeros(event,this);"></center>
					

                    <a href="#!" onclick="confirmaExclusao(<?php echo $row['codigo'];?>)" ><img src="img/lixeira.png" class="procurarb" width="25"> </a></td>


			<div class="clear-btn"> </div>
            <input class="btn-submit" type="submit" value="Atualizar">

                    </form>

                    <?php     }       // fim do if?>

			</div><!--// fechamento postagem-->

		</div>


           
        <script>

function confirmaExclusao(codigoprod){
    
    if(confirm('Deseja realmente excluir este Produto ?')){
        location.href='exclui_produto.php?codigoprod='+codigoprod;
    }

}

</script>

		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

	<script>
            const app = new Vue({
                el: '#app',
                data: {
                  errorcodigo: [],
                  codigo: null,
                },
                methods:{
                  checkForm: function (e) {
                    if (this.codigo) {
                      return true;
                    }
                    
                    this.errorcodigo = [];
    
                    if (!this.codigo) {
                      this.errorcodigo.push('O Codigo do Produto é Obrigatório');
                    }
                    
                    e.preventDefault();
                  }
                }
              })

              ({
			var elem = this;
            setTimeout(function(){
                // mudo a posição do seletor
                elem.selectionStart = elem.selectionEnd = 10000;
            }, 0);
            // reaplico o valor para mudar o foco
            var currentValue = $(this).val();
            $(this).val('');
            $(this).val(currentValue);
        });
        
		function ApenasLetras(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode <= 255) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };

    function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function ApenasNumerosPonto(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) || (charCode > 45 && charCode <= 47))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificaEmail(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode > 44 && charCode < 47) || (charCode > 94 && charCode < 96))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    
    function verificaComplemento(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificasenha(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 32 && charCode < 34) || (charCode > 34 && charCode < 39) || (charCode > 47 && charCode < 58) || (charCode > 62 && charCode < 91) || (charCode > 96 && charCode < 122))
            return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    /*UTILIZANDO O ENTER COMO BOTÃO - JQUERY */
    $(document).ready(function() {
    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
        var self = $(this)
                , form = self.parents('form:eq(0)')
                , focusable
                , next
                ;
        if (e.keyCode == 13) {
            focusable = form.find('input,a,select,button,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            } else {
                form.salvar();
            }
            return false;
        }
    });
});
    
    </script>
    
    

</body>
</html>