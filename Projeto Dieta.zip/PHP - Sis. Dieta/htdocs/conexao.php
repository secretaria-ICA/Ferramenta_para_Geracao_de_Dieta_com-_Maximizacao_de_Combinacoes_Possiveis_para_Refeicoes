<?php 

    //endereço, usuário, senha, base de dados
    $con = mysqli_connect("localhost","root","1234","dieta");

?>