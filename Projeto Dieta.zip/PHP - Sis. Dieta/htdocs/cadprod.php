<?php 
    include_once "autenticacao.php";

            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:cadprod.php");
              }if($_SESSION["perfil"] == "2"){                
                include_once ("location:cadprod.php");
            }if($_SESSION["perfil"] == "3"){                
                header("location:home2.php");
              }
            ?>

<div>Olá: <?php echo ($_SESSION["nome"])," Matricula:",($_SESSION["matricula"]);?> Seja Bem Vindo.

<!DOCTYPE html>

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<script src="/vue/vuev2.6.11.js"></script>		
	<script type="text/javascript" src="/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/jquery/jquery.mask.min.js"></script>	
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
        <h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
			<a href="home.php">Página Inicial</a>
			<a href="alt_prod_ex.php">Alteração / Exclusão de Produto</a>
		</div>
		
	</div>	

	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>Cadastro de Produtos</h2>

			</div><!--// fechamento postagem-->
			<form class="cad-prestador" id="app" @submit="checkForm" action="gravaProd.php" method="post">
		
			<div class="cadastro">

			

				<p class="erro" v-if="errorproddesc.length,errorkcal.length,errorquantidade.length,errortipo.length,errorcafe.length"><b>Por favor, corrija o(s) seguinte(s) erro(s):</b></p>		  

		
					<p>
						<label for="produto">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Descrição do Produto</label>
						<center><input class="input-cad-prestador" type="text" name="proddesc" placeholder="Descrição do Produto" v-model="proddesc" id="proddesc" maxlength="35" onkeypress="return ApenasLetras(event,this);"></center>
					</p>

					<ul>
						<li class="erro" v-for="error in errorproddesc">{{ error }}</li>
					  </ul>

					<p>
						<label for="kcal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kcal do Produto</label>
					<center><input class="input-cad-prestador" type="number" inputmode="numeric" step="0.01" name="kcal" placeholder="Kcal do Produto" v-model="kcal" id="kcal" maxlength="11" onkeypress="return ApenasNumerosPonto(event,this);"></center>
					</p>

					<ul>
						<li class="erro" v-for="error in errorkcal">{{ error }}</li>
					  </ul>

					<p>
						<label for="quantidade">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quantidade Porção</label>
					<center><input class="input-cad-prestador" type="text"  name="quantidade" placeholder="Quantidade Porção" v-model="quantidade" id="quantidade" maxlength="30"></center>
					</p>

					<ul>
						<li class="erro" v-for="error in errorquantidade">{{ error }}</li>
					  </ul>

                    
                    <p>
                    <center><label for="tipo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Categoria do Produto</label>
                    <select class="input-cad-prestador" name="tipo" id="tipo" v-model="tipo">
                    <option value="Proteina">Proteina</option>
                    <option value="Carboidrato">Carboidrato</option>
                    <option value="Frutas">Frutas</option>
                    <option value="Vegetais">Vegetais</option>
                    </select></center>
					</p>

					<ul>
						<li class="erro" v-for="error in errortipo">{{ error }}</li>
					  </ul>
					

					<p>
						<label for="cafe">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Produto Incluido no café da Dieta?</label>
					<center><input class="input-cad-prestador" type="number" inputmode="numeric" name="cafe" placeholder="0 se não - 1 se sim" v-model="cafe" id="cafe" maxlength="1" onkeypress="return ApenasNumeros(event,this);"></center>
					</p>

						
					<ul>
						<li class="erro" v-for="error in errorcafe">{{ error }}</li>
					  </ul>		

				</p>

			<div class="clear-btn"> </div>
            <input class="btn-submit" type="submit" value="Salvar">


</form>

			</div><!--// fechamento postagem-->

		</div>

		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

	<script>
            const app = new Vue({
                el: '#app',
                data: {
                  errorproddesc: [],
                  proddesc: null,
                  errorkcal: [],
                  kcal: null,
                  errorquantidade: [],
                  quantidade: null,
                  errortipo: [],
                  tipo: null,
                  errorcafe: [],
                  cafe: null,
                },
                methods:{
                  checkForm: function (e) {
                    if (this.proddesc && this.kcal && this.quantidade && this.tipo && this.cafe) {
                      return true;
                    }
                    
                    this.errorproddesc = [];
    
                    if (!this.proddesc) {
                      this.errorproddesc.push('A Descrição do Produto é obrigatória.');
                    }

                    this.errorkcal = [];
    
                    if (!this.kcal) {
                   this.errorkcal.push('A Caloria do Produto é obrigatória.');
                    }

    
                    this.errorquantidade = [];
    
                    if (!this.quantidade) {
                      this.errorquantidade.push('A quantidade do Produto é obrigatória.');
                    }
    
                    this.errortipo= [];
    
                    if (!this.tipo) {
                      this.errortipo.push('O Tipo do Produto é obrigatório.');
                    }
    
                    this.errorcafe = [];
    
                    if (!this.cafe) {
                      this.errorcafe.push('Obrigatório informar se o produto pode ser consumido no café.');
                    }
                    
                    e.preventDefault();
                  }
                }
              })

			      
			  $("#cpfcnpj").keydown(function(){
            try {
                $("#cpfcnpj").unmask();
            } catch (e) {}
        
            var tamanho = $("#cpfcnpj").val().length;
        
            if(tamanho < 11){
                $("#cpfcnpj").mask("999.999.999-99");
            } else {
                $("#cpfcnpj").mask("99.999.999/9999-99");
            }

			var elem = this;
            setTimeout(function(){
                // mudo a posição do seletor
                elem.selectionStart = elem.selectionEnd = 10000;
            }, 0);
            // reaplico o valor para mudar o foco
            var currentValue = $(this).val();
            $(this).val('');
            $(this).val(currentValue);
        });
        
		function ApenasLetras(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode <= 255) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };

    function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function ApenasNumerosPonto(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) || (charCode > 45 && charCode <= 47))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificaEmail(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode > 44 && charCode < 47) || (charCode > 94 && charCode < 96))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    
    function verificaComplemento(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificasenha(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 32 && charCode < 34) || (charCode > 34 && charCode < 39) || (charCode > 47 && charCode < 58) || (charCode > 62 && charCode < 91) || (charCode > 96 && charCode < 122))
            return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    /*UTILIZANDO O ENTER COMO BOTÃO - JQUERY */
    $(document).ready(function() {
    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
        var self = $(this)
                , form = self.parents('form:eq(0)')
                , focusable
                , next
                ;
        if (e.keyCode == 13) {
            focusable = form.find('input,a,select,button,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            } else {
                form.salvar();
            }
            return false;
        }
    });
});
    
    </script>
    
    

</body>
</html>