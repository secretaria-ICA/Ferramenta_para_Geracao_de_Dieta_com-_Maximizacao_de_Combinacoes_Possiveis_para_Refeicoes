<?php

session_start();

//se o usuário NÃO (!) está logado
if(!isset($_SESSION["matricula"])){
    session_destroy();

    $msg = "Acesso negado!!";
    header("location:index.php?msg=".$msg);
}

elseif($_SESSION["tempo"] + 5*60 < time()){
    session_destroy();

    $msg = "Sessão expirada!!";
    header("location:index.php?msg=".$msg);
}else{
    $_SESSION["tempo"] = time(); //renovando a sessao
}

?>