<?php 
    include_once "autenticacao.php";

            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:cadcli.php");
              }if($_SESSION["perfil"] == "2"){                
                header("location:home1.php");
            }if($_SESSION["perfil"] == "3"){                
                include_once ("location:cadcli.php");
              }
            ?>

<div>Olá: <?php echo ($_SESSION["nome"])," Matricula:",($_SESSION["matricula"]);?> Seja Bem Vindo.

<!DOCTYPE html>

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<script src="/vue/vuev2.6.11.js"></script>		
	<script type="text/javascript" src="/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/jquery/jquery.mask.min.js"></script>	
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
        <h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
            <a href="home.php">Página Inicial</a>
			<a href="alt_cli_ex.php">Alteração / Exclusão de Cliente</a>
		</div>
		
	</div>	

	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>Cadastro de Clientes</h2>

			</div><!--// fechamento postagem-->
			<form class="cad-prestador" id="app" @submit="checkForm" action="gravaCli.php" method="post">
			<!-- abertura postagem-->
			<div class="cadastro">


				<p class="erro" v-if="errornome.length,errorcpf.length,errorpeso.length,erroraltura.length,errortelefone.length,errorendereco.length,errornumero.length,erroremail.length,errorcep.length,errorsexo.length"><b>Por favor, corrija o(s) seguinte(s) erro(s):</b></p>		  

					<p>
						<label for="nome">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nome</label>
						<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="nome" placeholder="Nome do Cliente" v-model="nome" id="nome" maxlength="60" onkeypress="return ApenasLetras(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in errornome">{{ error }}</li>
					  </ul>		

					<p>
						<label for="cpf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CPF</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="cpf" placeholder="CPF do Cliente" v-model="cpf" id="cpf" maxlength="11" onkeypress="return ApenasNumeros(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in errorcpf">{{ error }}</li>
					  </ul>		

					<p>
						<label for="peso">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Peso</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="peso" placeholder="Peso do Cliente" v-model="peso" id="peso" maxlength="6" onkeypress="return ApenasNumerosPonto(event,this);"></center>
					</p>
                    
                      <ul>
						<li class="erro" v-for="error in errorpeso">{{ error }}</li>
					  </ul>		

					<p>
						<label for="altura">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Altura</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="altura" placeholder="Altura do Cliente" v-model="altura" id="altura" maxlength="6" onkeypress="return ApenasNumerosPonto(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in erroraltura">{{ error }}</li>
					  </ul>		

					<p>
						<label for="telefone">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Telefone</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="telefone" placeholder="Digite o Telefone do Cliente" v-model="telefone" id="telefone" maxlength="11" onkeypress="return ApenasNumeros(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in errortelefone">{{ error }}</li>
					  </ul>		

					<p>
						<label for="endereco">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Endereço</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="endereco" placeholder="Digite o Endereço do Cliente" v-model="endereco" id="endereco" maxlength="30" onkeypress="return verificaComplemento(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in errorendereco">{{ error }}</li>
					  </ul>	

					<p>
						<label for="Nº da Casa">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nº da Casa</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="numero" placeholder="Digite o numero da casa" v-model="numero" id="numero" maxlength="10" onkeypress="return ApenasNumeros(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in errornumero">{{ error }}</li>
					  </ul>	

					<p>
						<label for="email">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="email" placeholder="Digite o email do Cliente" v-model="email" id="email" maxlength="60" onkeypress="return verificaEmail(event,this);"></center>
					</p>

                      <ul>
						<li class="erro" v-for="error in erroremail">{{ error }}</li>
					  </ul>	

					<p>
						<label for="cep">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cep</label>
					<center><input class="input-cad-prestador" type="text" inputmode="numeric" name="cep" placeholder="Digite o cep do Cliente" v-model="cep" id="cep" maxlength="8" onkeypress="return ApenasNumeros(event,this);"></center>
					</p>

                       <ul>
						<li class="erro" v-for="error in errorcep">{{ error }}</li>
					  </ul>	

                      <br>
                    <label for="sexo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sexo</label>
                    <br>
                      <div class="alinha-radio">
								<input type="radio" id="1"
							   name="sexo" type="radio" value="M" v-model="sexo" />
							  <label for="contactChoice1">Masculino</label>
							
							  <input type="radio" id="0"
							   name="sexo" value="F" v-model="sexo"  />
							  <label for="contactChoice2">Feminino</label>
                    </div>
                      <ul>
						<li class="erro" v-for="error in errorsexo">{{ error }}</li>
					  </ul>		


				</p>

			<div class="clear-btn"> </div>
            <input class="btn-submit" type="submit" value="Salvar">


</form>

			</div><!--// fechamento postagem-->

		</div>

		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

	<script>
            const app = new Vue({
                el: '#app',
                data: {
                  errornome: [],
                  nome: null,
                  errorcpf: [],
                  cpf: null,
                  errorpeso: [],
                  peso: null,
                  erroraltura: [],
                  altura: null,
                  errortelefone: [],
                  telefone: null,
                  errorendereco: [],
                  endereco: null,
                  errornumero: [],
                  numero: null,
                  erroremail: [],
                  email: null,
                  errorcep: [],
                  cep: null,
                  errorsexo: [],
                  sexo: null,
                },
                methods:{
                  checkForm: function (e) {
                    if (this.nome && this.cpf && this.peso && this.altura && this.telefone && this.endereco && this.numero && this.email && this.cep) {
                      return true;
                    }
                    
                    this.errornome = [];
    
                    if (!this.nome) {
                      this.errornome.push('A Matricula do Usuário é obrigatória.');
                    }

                    this.errorcpf = [];
    
                    if (!this.cpf) {
                   this.errorcpf.push('O Nome do Usuário é obrigatório.');
                    }

    
                    this.errorpeso = [];
    
                    if (!this.peso) {
                      this.errorpeso.push('A Senha do usuário é obrigatória.');
                    }
    
                    this.erroraltura= [];
    
                    if (!this.altura) {
                      this.erroraltura.push('O Perfil do Usuário é Obrigatório.');
                    }
    
                    this.errortelefone = [];
    
                    if (!this.telefone) {
                      this.errortelefone.push('Informar o Telefone do Cliente é Obrigatório.');
                    }

                    this.errorendereco = [];
    
                    if (!this.endereco) {
                    this.errorendereco.push('Informar o Endereço do Cliente é Obrigatório.');
                    }

                    this.errornumero = [];
                    
                    if (!this.numero) {
                    this.errornumero.push('Informar o Número do Endereço do Cliente é Obrigatório.');
                    }

                    this.erroremail = [];
                    
                    if (!this.email) {
                    this.erroremail.push('Informar o e-mail do Cliente é obrigatório.');
                    }

                    this.errorcep = [];
                    
                    if (!this.cep) {
                    this.errorcep.push('Informar o CEP do Cliente é Obrigatório.');
                    }

                    this.errorsexo = [];
                    
                    if (!this.sexo) {
                    this.errorsexo.push('Informar o Sexo do Cliente é Obrigatório.');
                    }
                    
                    e.preventDefault();
                  }
                }
              })

			      
			  $("#cpfcnpj").keydown(function(){
            try {
                $("#cpfcnpj").unmask();
            } catch (e) {}
        
            var tamanho = $("#cpfcnpj").val().length;
        
            if(tamanho < 11){
                $("#cpfcnpj").mask("999.999.999-99");
            } else {
                $("#cpfcnpj").mask("99.999.999/9999-99");
            }

			var elem = this;
            setTimeout(function(){
                // mudo a posição do seletor
                elem.selectionStart = elem.selectionEnd = 10000;
            }, 0);
            // reaplico o valor para mudar o foco
            var currentValue = $(this).val();
            $(this).val('');
            $(this).val(currentValue);
        });
        
		function ApenasLetras(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode <= 255) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };

    function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function ApenasNumerosPonto(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) || (charCode > 45 && charCode <= 47))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificaEmail(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode > 44 && charCode < 47) || (charCode > 94 && charCode < 96))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    
    function verificaComplemento(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificasenha(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 32 && charCode < 34) || (charCode > 34 && charCode < 39) || (charCode > 47 && charCode < 58) || (charCode > 62 && charCode < 91) || (charCode > 96 && charCode < 122))
            return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    /*UTILIZANDO O ENTER COMO BOTÃO - JQUERY */
    $(document).ready(function() {
    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
        var self = $(this)
                , form = self.parents('form:eq(0)')
                , focusable
                , next
                ;
        if (e.keyCode == 13) {
            focusable = form.find('input,a,select,button,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            } else {
                form.salvar();
            }
            return false;
        }
    });
});
    
    </script>
    
    

</body>
</html>