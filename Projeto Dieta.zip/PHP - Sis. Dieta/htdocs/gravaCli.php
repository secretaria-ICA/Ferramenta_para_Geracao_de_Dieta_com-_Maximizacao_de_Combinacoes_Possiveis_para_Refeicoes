

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $peso = $_POST["peso"];
    $altura = $_POST["altura"];
    $telefone = $_POST["telefone"];
    $endereco = $_POST["endereco"];
    $numero = $_POST["numero"];
    $email = $_POST["email"];
    $cep = $_POST["cep"];
    $sexo = $_POST["sexo"];
    $imc =    number_format($peso/($altura * 2),2);

    
    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de insert
    $sql = "insert into tbCliente (nome,cpf,peso,altura,telefone,endereco,rua,email,cep,imc,sexo,pesoideal) 
    values('".$nome."',".$cpf.",".$peso.",".$altura.",'".$telefone."','".$endereco."',".$numero.",'".$email."',".$cep.",".$imc.",'".$sexo."',case when '".$sexo."'='F' then 21*($altura * 2) else 22*($altura * 2) end)";
//    echo $sql;  
   //sleep(15)
   

    
    //4- Executar a instrução SQL
    if(mysqli_query($con,$sql)) {
        $msg = "Cliente cadastrado com sucesso!";
    }else{
        $msg = "Erro ao cadastrar o Cliente!";
    }
    

    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="cadcli.php"; //redirecionamento em JS
</script>