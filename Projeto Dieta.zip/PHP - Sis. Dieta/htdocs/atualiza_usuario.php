

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $matricula = $_POST["matricula"];
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];
    $perfil = $_POST["perfil"];
    $ativoinativo = $_POST["ativoinativo"];
    
    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de alteração
$sql = "update dieta.tbusuario set nome='".$nome."',senha=CASE when (senha='".$senha."') then '".$senha."' else '".$senha."' end, perfil=".$perfil.",
ativo=".$ativoinativo." where matricula = ".$matricula."";
    
    
    if(mysqli_query($con,$sql)) {
        $msg = "Dados do Usuário atualizados com sucesso!";
    }else{
        $msg = "Erro ao atualizar os dados do Usuário!";
    }



    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="alt_user_ex.php"; //redirecionamento em JS
</script>