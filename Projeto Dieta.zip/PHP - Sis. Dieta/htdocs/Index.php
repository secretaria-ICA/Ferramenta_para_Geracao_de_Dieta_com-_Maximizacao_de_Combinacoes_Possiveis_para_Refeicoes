<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Sistema Dieta+Saúde</title>
		<link rel="stylesheet" type="text/css" href="css/estilo.css">

	


	</head>

	<body>

		<div id="area-cabecalho">

		<div id="area-logo">
			<h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>
</div>
<br>


		<section>
			<div class="login-admin">
				<form class="log" action="verifica-login.php" method="post" autocomplete="off">
						<center><label for="matricula">Matricula</label></center>
						<center><input class="input-login" type="text" name="matricula" id="matricula" placeholder="Matricula" maxlength="5" onkeypress="return ApenasNumeros(event,this);"></center>

									
						<center><label for="senha">Senha</label></center>
						<center><input class="input-login" type="password" name="senha" placeholder="Senha"></center>				
						<center><input type="submit" value="Entrar" class="btn-submit"></center>
				</form>
			</div>
		</section>
	</body>
</html>


<script>
function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
}
		</script>