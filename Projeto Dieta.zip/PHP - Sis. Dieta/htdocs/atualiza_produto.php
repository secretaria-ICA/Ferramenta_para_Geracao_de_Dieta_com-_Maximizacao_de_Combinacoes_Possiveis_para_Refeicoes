

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $codigoprod = $_POST["codigoprod"];
    $proddesc = $_POST["proddesc"];
    $kcal = $_POST["kcal"];
    $quantidade = $_POST["quantidade"];
    $tipo = $_POST["tipo"];
    $cafe = $_POST["cafe"];
    

    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de alteração   
$sql = "update dieta.tbproduto set nome='".$proddesc."',kcal=".$kcal.", quantidade=".$quantidade.",
categoria='".$tipo."', cafe=".$cafe." where codigo = ".$codigoprod."";

    
    if(mysqli_query($con,$sql)) {
        $msg = "Dados atualizados com sucesso!";
    }else{
        $msg = "Erro ao atualizar!";
    }

       //echo $sql;  
   //sleep(15)


    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="alt_prod_ex.php"; //redirecionamento em JS
</script>