

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $cpf = $_GET["cpf"];


    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de delete
$sql = "delete from dieta.tbdietacli where cpf=".$cpf." and datagerada=date_format(CURRENT_DATE, '%d/%m/%Y')";

    //echo $sql;
   //sleep(15)

    
    //4- Executar a instrução SQL
    if(mysqli_query($con,$sql)) {
        $msg = "Dieta Excluida com Sucesso para este cliente";
    }else{
        $msg = "Erro ao Excluir a Dieta para este cliente";
    }
    

    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="incluidieta.php"; //redirecionamento em JS
</script>