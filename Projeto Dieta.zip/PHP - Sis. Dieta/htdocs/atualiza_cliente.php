

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $nome = $_POST["nome"];
    $cpf = $_POST["cpf"];
    $peso = $_POST["peso"];
    $altura = $_POST["altura"];
    $telefone = $_POST["telefone"];
    $endereco = $_POST["endereco"];
    $numero = $_POST["numero"];
    $email = $_POST["email"];
    $cep = $_POST["cep"];
    
    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de alteração
$sql = "update dieta.tbcliente set nome='".$nome."', peso=".$peso.",
altura=".$altura.", telefone=".$telefone.", endereco='".$endereco."', rua=".$numero.", email='".$email."' , cep=".$cep."  where cpf = ".$cpf."";
    
    
    if(mysqli_query($con,$sql)) {
        $msg = "Dados do Cliente atualizados com sucesso!";
    }else{
        $msg = "Erro ao atualizar os dados do Cliente!";
    }


    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="alt_cli_ex.php"; //redirecionamento em JS
</script>