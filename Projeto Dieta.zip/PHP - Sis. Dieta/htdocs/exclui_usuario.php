

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
     $matricula = $_GET["matricula"];
    
    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de delete
$sql = "delete from dieta.tbusuario where matricula = ".$matricula."";

    
    
    if(mysqli_query($con,$sql)) {
        $msg = "Usuário Excluido com sucesso!";
    }else{
        $msg = "Erro ao excluir o Usuário!";
    }

       //echo $sql;  
   //sleep(15)


    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="alt_user_ex.php"; //redirecionamento em JS
</script>