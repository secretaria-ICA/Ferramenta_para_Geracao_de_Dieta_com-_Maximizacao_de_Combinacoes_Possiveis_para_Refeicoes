
<?php 


set_time_limit(200);
$retorno = system("c:\\WINDOWS\\system32\\cmd.exe /c START C:/pdi-ce-8.1.0.0/data-integration/start.cmd");

 echo $resolvido;
 $msg = "Dieta Gerada com Sucesso";

?>

 <script>

    alert('<?php echo $msg; ?>');
    location.href="geradieta.php"; //redirecionamento em JS
</script> 
