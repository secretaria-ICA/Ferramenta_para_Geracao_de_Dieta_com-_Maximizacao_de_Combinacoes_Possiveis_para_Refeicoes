<?php 

    echo time();

?>