<?php
session_start();

function logout() {
	session_destroy();
}