<?php 
include_once "conexao.php";
    include_once "autenticacao.php";

            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:caduser.php");
              }if($_SESSION["perfil"] == "2"){                
                header("location:home1.php");
            }if($_SESSION["perfil"] == "3"){                
                include_once ("location:caduser.php");
              }
            ?>

            <div>Olá: <?php echo ($_SESSION["nome"])," ",($_SESSION["matricula"]);?> Seja Bem Vindo.
        

            <?php
            //isset() -> Verifica se a variável existe e está diferente de null
            if(isset($_GET["codigo"])){

                $codigo = $_GET["codigo"];

                $con = mysqli_connect("localhost","root","1234","dieta");

                $sql = "select * from tbusuario where matricula='$codigo' or nome like '%$codigo%' limit 1";
                //echo $sql;

                //Executar a consulta
                $result = mysqli_query($con,$sql);                
                //var_dump($result); mostra o conteúdo de uma variável

                if(mysqli_num_rows($result) > 0){
                    //echo "ok";
                    
                }
              }
                    ?>

<!DOCTYPE html>

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<script src="/vue/vuev2.6.11.js"></script>		
	<script type="text/javascript" src="/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/jquery/jquery.mask.min.js"></script>	
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
        <h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
			<a href="home.php">Página Inicial</a>
            <a href="caduser.php">Cadastro de Usuário</a>
		</div>
		
	</div>	

	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>Alteração / Exclusão de Usuário</h2>

			</div><!--// fechamento postagem-->
			<form class="cad-prestador" id="app" @submit="checkForm" action="alt_user_ex.php" method="GET">

			<div class="cadastro">

			
					
						<label for="codigo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pesquise pela Matricula ou Nome do Usuário<input class="procurarb" type="image" src="img/buscar.png" width="25"></label>
                        <center><input class="input-cad-prestador" type="text" v-model="codigo" name="codigo" placeholder="Codigo do Produto ou Nome do Produto"  id="codigo" maxlength="10" onkeypress="return ApenasNumeros(event,this);"></center>
			

                                        </form>

                      <form class="cad-prestador" action="atualiza_usuario.php" method="POST">

                    <?php
                    // finaliza o loop que vai mostrar os dados
                    while($row = mysqli_fetch_array($result)){?>


              <input type="hidden" value="<?php echo $row["matricula"];?>" name="codigo" id="codigo">
              <input type="hidden" value="<?php echo $row["nome"];?>" name="codigo" id="codigo">


                        <label for="matricula">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Matricula do Usuário</label>
						<center><input class="input-cad-prestador" type="text" name="matricula" value="<?php echo $row["matricula"];?>" placeholder="Matricula do Usuário"  id="matricula" maxlength="10" onkeypress="return ApenasNumeros(event,this);"></center>
                    
						<label for="nome">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nome do Usuário</label>
						<center><input class="input-cad-prestador" type="text" name="nome" value="<?php echo $row["nome"];?>" placeholder="Nome do Usuário"  id="nome" maxlength="60" onkeypress="return ApenasLetras(event,this);"></center>
					

					
						<label for="senha">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Senha do Usuário</label>
					<center><input class="input-cad-prestador" type="password" value="<?php echo $row["senha"];?>" name="senha" placeholder="Senha do Usuário"  id="senha" maxlength="100" onkeypress="return verificasenha(event,this);"></center>
					
                    <br>
                    <label for="perfil">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Perfil do Usuário</label>
                    <br>
                        <br>
                                 <div class="alinha-radio">
								<input type="radio" id="p1"
							   name="perfil" type="radio" value="1" <?= ($row['perfil'] == '1') ? 'checked' : ''  ?> />
							  <label for="contactChoice1">Administrador</label>
							
							  <input type="radio" id="p2"
							   name="perfil" value="2" <?= ($row['perfil'] == '2') ? 'checked' : ''  ?> />
							  <label for="contactChoice2">Nutricionista</label>

                              <input type="radio" id="p3"
							   name="perfil" value="3" <?= ($row['perfil'] == '3') ? 'checked' : ''  ?> />
							  <label for="contactChoice3">Recepcionista</label>
                    </div>

                    <br>
                   <center><hr size="1" width="50%" align="center" noshade></center>
                   <br>
                   
                    <label for="ativoinativo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Usuário Ativo/Inativo</label>
                        <br>
                        <br>
                    <div class="alinha-radio">
								<input type="radio" id="1"
							   name="ativoinativo" type="radio" value="1" <?= ($row['ativo'] == '1') ? 'checked' : ''  ?> />
							  <label for="contactChoice1">Usuário Ativo</label>
							
							  <input type="radio" id="0"
							   name="ativoinativo" value="0" <?= ($row['ativo'] == '0') ? 'checked' : ''  ?> />
							  <label for="contactChoice2">Usuário Inativo</label>
                    </div>
                    <br>
                   


					
                    <a href="#!" onclick="confirmaExclusao(<?php echo $row['matricula'];?>)" ><img src="img/lixeira.png" class="procurarb" width="25"> </a></td>


			<div class="clear-btn"> </div>
            <input class="btn-submit" type="submit" value="Atualizar">

                    </form>

                    <?php     }       // fim do if?>


			</div><!--// fechamento postagem-->

		</div>


           
        <script>

function confirmaExclusao(matricula){
    
    if(confirm('Deseja realmente excluir este Produto ?')){
        location.href='exclui_usuario.php?matricula='+matricula;
    }

}

</script>

		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

	<script>
            const app = new Vue({
                el: '#app',
                data: {
                  errorcodigo: [],
                  codigo: null,
                },
                methods:{
                  checkForm: function (e) {
                    if (this.codigo) {
                      return true;
                    }
                    
                    this.errorcodigo = [];
    
                    if (!this.codigo) {
                      this.errorcodigo.push('O Codigo do Produto é Obrigatório');
                    }
                    
                    e.preventDefault();
                  }
                }
              })

              ({
			var elem = this;
            setTimeout(function(){
                // mudo a posição do seletor
                elem.selectionStart = elem.selectionEnd = 10000;
            }, 0);
            // reaplico o valor para mudar o foco
            var currentValue = $(this).val();
            $(this).val('');
            $(this).val(currentValue);
        });
        
		function ApenasLetras(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode <= 255) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };

    function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function ApenasNumerosPonto(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) || (charCode > 45 && charCode <= 47))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificaEmail(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode > 44 && charCode < 47) || (charCode > 94 && charCode < 96))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    
    function verificaComplemento(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificasenha(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 32 && charCode < 34) || (charCode > 34 && charCode < 39) || (charCode > 47 && charCode < 58) || (charCode > 62 && charCode < 91) || (charCode > 96 && charCode < 122))
            return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    /*UTILIZANDO O ENTER COMO BOTÃO - JQUERY */
    $(document).ready(function() {
    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
        var self = $(this)
                , form = self.parents('form:eq(0)')
                , focusable
                , next
                ;
        if (e.keyCode == 13) {
            focusable = form.find('input,a,select,button,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            } else {
                form.salvar();
            }
            return false;
        }
    });
});
    
    </script>
    
    

</body>
</html>