

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
     $codigoprod = $_GET["codigoprod"];
 
    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de delete
$sql = "delete from dieta.tbproduto where codigo = ".$codigoprod."";


    if(mysqli_query($con,$sql)) {
        $msg = "Produto Excluido com sucesso!";
    }else{
        $msg = "Erro ao excluir o Produto!";
    }

       //echo $sql;  
   //sleep(15)

    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="alt_prod_ex.php"; //redirecionamento em JS
</script>