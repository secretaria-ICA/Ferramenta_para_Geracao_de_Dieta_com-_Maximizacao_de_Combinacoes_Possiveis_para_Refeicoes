<?php
    session_start(); //espaço de memória no navegador

    $matricula = $_POST["matricula"];
    $senha = md5($_POST["senha"]);

    $con = mysqli_connect("localhost","root","1234","dieta");

    $sql = "select * from tbusuario where matricula = ".$matricula." and senha = '".$senha."'";

    $result = mysqli_query($con,$sql);

    if(mysqli_num_rows($result) == 1){
        
        $row = mysqli_fetch_array($result);
        //var_dump($row);

        //SESSÃO (Guardando valores no navegador)
        $_SESSION["matricula"] = $row["matricula"];
        $_SESSION["nome"] = $row["nome"];
        $_SESSION["perfil"] = $row["perfil"];
        $_SESSION["ativo"] = $row["ativo"];
        $_SESSION["tempo"] = time(); //registrando o instante que o usuario se logou
        

        //Redirecionar para o painel
        header("location:home.php");

    }else{
        $msg = "Login/Senha inválido(s)";
        header("location:index.php?msg=".$msg);
    }

    mysqli_close($con);

?>
