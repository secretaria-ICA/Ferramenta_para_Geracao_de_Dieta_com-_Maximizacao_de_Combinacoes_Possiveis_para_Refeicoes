<?php
include_once "conexao.php";
 
    include_once "autenticacao.php";

            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:geradieta.php");
              }if($_SESSION["perfil"] == "2"){                
                include_once ("location:geradieta.php");
            }if($_SESSION["perfil"] == "3"){                
                header("location:home2.php");
              }
            

?>


            <div>Olá: <?php echo ($_SESSION["nome"])," ",($_SESSION["matricula"]);?> Seja Bem Vindo.
        

            <?php
            //isset() -> Verifica se a variável existe e está diferente de null
            if(isset($_GET["codigo"])){

                $codigo = $_GET["codigo"];

                $con = mysqli_connect("localhost","root","1234","dieta");

                $sql = "select * from dieta.tbcliente where cpf='$codigo' or nome like '%$codigo%' limit 1";
                //echo $sql;

                //Executar a consulta
                $result = mysqli_query($con,$sql);                
                //var_dump($result); mostra o conteúdo de uma variável

                if(mysqli_num_rows($result) > 0){
                    //echo "ok";

                }
              }
                    ?>

<!DOCTYPE html>

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<script src="/vue/vuev2.6.11.js"></script>		
	<script type="text/javascript" src="/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/jquery/jquery.mask.min.js"></script>	
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
        <h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
			<a href="home.php">Página Inicial</a>
            <a href="geradieta.php">Gera Dieta</a>
            <a href="incluidieta.php">Inclui Dieta</a>
		</div>
		
	</div>	

	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>Baixa Dieta do Cliente</h2>
				

			</div><!--// fechamento postagem-->
			<form class="cad-prestador" id="app" @submit="checkForm" action="BaixaDietaCli.php" method="GET">
			<!-- abertura postagem-->
			<div class="cadastro">
	
					
						<label for="codigo">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pesquise pelao CPF ou Nome do Cliente<input class="procurarb" type="image" src="img/buscar.png" width="25"></label>
                        <center><input class="input-cad-prestador" type="text" v-model="codigo" name="codigo" placeholder="Codigo do Produto ou Nome do Produto"  id="codigo" maxlength="30" onkeypress="return ApenasNumeros(event,this);"></center>
			

                                        </form>

                      <form class="cad-prestador" action="baixa_xls_cli.php" method="POST">

                    <?php
                    // finaliza o loop que vai mostrar os dados
                    while($row = mysqli_fetch_array($result)){?>


              <input type="hidden" value="<?php echo $row["cpf"];?>" name="codigo" id="codigo">
              <input type="hidden" value="<?php echo $row["nome"];?>" name="codigo" id="codigo">


                        <label for="nome">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nome do Cliente</label>
						<center><input class="input-cad-prestador" type="text" name="nome" value="<?php echo $row["nome"];?>" placeholder="Nome do Cliente"  id="nome" maxlength="60" onkeypress="return ApenasLetras(event,this);"></center>
					


                        <label for="cpf">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CPF Cliente</label>
						<center><input class="input-cad-prestador" type="number" name="cpf" value="<?php echo $row["cpf"];?>" placeholder="CPF do Cliente"  id="cpf" maxlength="11" onkeypress="return ApenasNumeros(event,this);"></center>
                    

			<div class="clear-btn"> </div>
            <input class="btn-submit" type="submit" value="Baixa Dieta">

                    </form>

                    <?php     }       // fim do if?>

			</div><!--// fechamento postagem-->

		</div>


           
        <script>

function confirmaExclusao(cpf){
    
    if(confirm('Deseja realmente excluir a Dieta do Cliente ?')){
        location.href='gravaDieta.php?cpf='+cpf;
    }

}

</script>

		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

	<script>
            const app = new Vue({
                el: '#app',
                data: {
                  errorcodigo: [],
                  codigo: null,
                },
                methods:{
                  checkForm: function (e) {
                    if (this.codigo) {
                      return true;
                    }
                    
                    this.errorcodigo = [];
    
                    if (!this.codigo) {
                      this.errorcodigo.push('O Codigo do Produto é Obrigatório');
                    }
                    
                    e.preventDefault();
                  }
                }
              })

              $("#cpf").keydown(function(){
            try {
                $("#cpf").unmask();
            } catch (e) {}
        
            var tamanho = $("#cpf").val().length;
        
            if(tamanho = 11){
                $("#cpf").mask("999.999.999-99");
            } 
            }

            $("#telefone").keydown(function(){
            try {
                $("#telefone").unmask();
            } catch (e) {}
        
            var tamanho = $("#telefone").val().length;
        
            if(tamanho = 11){
                $("#telefone").mask("(99)9999-99999");
            } 
            }

              ({
			var elem = this;
            setTimeout(function(){
                // mudo a posição do seletor
                elem.selectionStart = elem.selectionEnd = 10000;
            }, 0);
            // reaplico o valor para mudar o foco
            var currentValue = $(this).val();
            $(this).val('');
            $(this).val(currentValue);
        });
        
		function ApenasLetras(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode <= 255) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };

    function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function ApenasNumerosPonto(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) || (charCode > 45 && charCode <= 47))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificaEmail(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode > 44 && charCode < 47) || (charCode > 94 && charCode < 96))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    
    function verificaComplemento(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificasenha(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 32 && charCode < 34) || (charCode > 34 && charCode < 39) || (charCode > 47 && charCode < 58) || (charCode > 62 && charCode < 91) || (charCode > 96 && charCode < 122))
            return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    /*UTILIZANDO O ENTER COMO BOTÃO - JQUERY */
    $(document).ready(function() {
    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
        var self = $(this)
                , form = self.parents('form:eq(0)')
                , focusable
                , next
                ;
        if (e.keyCode == 13) {
            focusable = form.find('input,a,select,button,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            } else {
                form.salvar();
            }
            return false;
        }
    });
});
    
    </script>
    
    

</body>
</html>