

<?php
   
   include_once "autenticacao.php";
    //Processo de gravação em banco de dados

    //1- Resgatar os dados do formulário
    
    $proddesc = $_POST["proddesc"];
    $kcal = $_POST["kcal"];
    $quantidade = $_POST["quantidade"];
    $tipo = $_POST["tipo"];
    $cafe = $_POST["cafe"];
    


    
    //2- Conectar ao MYSQL
    include "conexao.php";


    //3- Montar a instrução sql de insert
    $sql = "insert into tbproduto (nome,kcal,quantidade,categoria,cafe) values('".$proddesc."',".$kcal.",'".$quantidade."','".$tipo."',".$cafe.")";
   //echo $sql;  
   //sleep(15)
   

    
    //4- Executar a instrução SQL
    if(mysqli_query($con,$sql)) {
        $msg = "Produto Inserido com sucesso!";
    }else{
        $msg = "Erro ao gravar o Produto!";
    }
    


    //5- fechar a conexão
    mysqli_close($con);
  
?>

<script>
    alert('<?php echo $msg; ?>');
    location.href="cadprod.php"; //redirecionamento em JS
</script>