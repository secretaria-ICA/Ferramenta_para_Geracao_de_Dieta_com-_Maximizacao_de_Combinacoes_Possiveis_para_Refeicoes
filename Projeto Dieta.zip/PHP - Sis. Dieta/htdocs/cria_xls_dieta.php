﻿<?php

        //incluimos nossa conexão
        include_once('Conexao.class.php');
        //instanciamos
        $pdo = new conexao ();
        //mandamos nossa query para nosso método dentro de conexao dando um return $stmt->fetchAll(PDO::FETCH_ASSOC);
        $result = $pdo->select("SELECT id, item, kcal, QtdPorcao, categoria, Refeicao, case when dia=1 then 'Segunda' when dia=2 then 'Terça' when dia=3 then 'Quarta' when dia=4 then 'Quinta' when dia=5 then 'Sexta' when dia=6 then 'Sábado' when dia=7 then 'Domingo' end dias, date_format(CURRENT_DATE, '%d/%m/%Y') as Data_Gerada FROM dieta.tbtempdiasdieta order by  dia, refeicao='Janta',refeicao='Lanche da Tarde',refeicao='Almoço',refeicao='Café'");

   
        //declaramos uma variavel para monstarmos a tabela
        $dadosXls .= "  <table border='0' and bgcolor=#a626a6>";
    $dadosXls .= "          <center><tr>";
        $dadosXls .= "          <th></th>";
        $dadosXls .= "          <th></th>";
        $dadosXls .= "          <th></th>";
        $dadosXls .= "          <th>SISTEMA DIETA</th>";
        $dadosXls .= "          <th></th>";
        $dadosXls .= "          <th></th>";
        $dadosXls .= "          <th></th>";
        $dadosXls .= "      </tr><center/>";
        $dadosXls .= "  <table border='1' and bgcolor=#94568d>";
    $dadosXls .= "          <tr>";
        $dadosXls .= "          <th>ID ITEM</th>";
        $dadosXls .= "          <th>DESCRIÇÃO DO ITEM</th>";
        $dadosXls .= "          <th>KCAL</th>";
		$dadosXls .= "          <th>QUANTIDADE PORÇÃO</th>";
        $dadosXls .= "          <th>CATEGORIA DO PRODUTO</th>";
        $dadosXls .= "          <th>REFEIÇÃO</th>";
        $dadosXls .= "          <th>DIAS DA SEMANA</th>";
        $dadosXls .= "          <th>DATA DIETA GERADA</th>";
        $dadosXls .= "      </tr>";

        //$result = $pdo->select("SELECT id,nome,email FROM cadastro");
        //varremos o array com o foreach para pegar os dados
        foreach($result as $res){
            $dadosXls .= "  <table border='1' and bgcolor='#f0ddee'>";
            $dadosXls .= "      <tr>";
            $dadosXls .= "          <td><center>".$res['id']."<center/></td>";
            $dadosXls .= "          <td><center>".$res['item']."<center/></td>";
            $dadosXls .= "          <td><center>".$res['kcal']."<center/></td>";
            $dadosXls .= "          <td><center>".$res['QtdPorcao']."<center/></td>";
            $dadosXls .= "          <td><center>".$res['categoria']."<center/></td>";
            $dadosXls .= "          <td><center>".$res['Refeicao']."<center/></td>";
            $dadosXls .= "          <td><center>".$res['dias']."<center/></td>";
			$dadosXls .= "          <td><center>".$res['Data_Gerada']."<center/></td>";
            $dadosXls .= "      </tr>";
        }
        $dadosXls .= "  </table>";

        $Datetime = date('d/m/Y H:i:s');
     
        // Definimos o nome do arquivo que será exportado  
        $arquivo = "Dieta-$Datetime.xls";  
        // Configurações header para forçar o download  
        header('Content-type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$arquivo.'"');
        header('Cache-Control: max-age=0');
        // Se for o IE9, isso talvez seja necessário
        header('Cache-Control: max-age=1');
           
        // Envia o conteúdo do arquivo  
        echo $dadosXls;  
        

echo "\n";

   ?>

