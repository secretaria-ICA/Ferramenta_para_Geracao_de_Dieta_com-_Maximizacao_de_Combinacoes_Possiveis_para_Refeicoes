<?php


 
    include_once "autenticacao.php";

            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:geradieta.php");
              }if($_SESSION["perfil"] == "2"){                
                include_once ("location:geradieta.php");
            }if($_SESSION["perfil"] == "3"){                
                header("location:home2.php");
              }
            

?>

<!DOCTYPE html>

<div>Olá: <?php echo ($_SESSION["nome"])," Matricula:",($_SESSION["matricula"]);?> Seja Bem Vindo.

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
		<h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
			<a href="home.php">Página Inicial</a>
			<a href="incluidieta.php">Inclui Dieta</a>
			<a href="BaixaDietaCli.php">Baixar Dieta do Cliente</a>
		</div>
		
	</div>	

	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>Gerar Dieta</h2>
	

			</div><!--// fechamento postagem-->

			<!-- abertura postagem-->
			<div class="cadastro">
		
				<p>
				<form class="log" action="chamacmd.php" method="post" autocomplete="off">			
				<center><input type="submit" value="Gera Dieta" class="btn-submit"></center>
				</form>

				<form class="log" action="cria_xls_dieta.php" method="post" autocomplete="off">			
				<center><input type="submit" value="Baixar Dieta Gerada" class="btn-submit"></center>
				</form>
				

				</p>
	

			</div><!--// fechamento postagem-->

		</div>


		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

</body>
</html>