<?php 
    include_once "autenticacao.php";

            if($_SESSION["ativo"] == "0"){                
              header("location:index.php");
            }if($_SESSION["perfil"] == "1"){                
                include_once ("location:dashboard.php");
              }if($_SESSION["perfil"] == "2"){                
                header("location:home1.php");
            }if($_SESSION["perfil"] == "3"){                
                header("location:home2.php");
              }
            ?>

<div>Olá: <?php echo ($_SESSION["nome"])," Matricula:",($_SESSION["matricula"]);?> Seja Bem Vindo.

<!DOCTYPE html>

<html>

<head>

	<title>Sistema Dieta+Saúde</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<script src="/vue/vuev2.6.11.js"></script>		
	<script type="text/javascript" src="/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="/jquery/jquery.mask.min.js"></script>	
	

</head>

<body>

	<div id="area-cabecalho">

		<div id="area-logo">
        <h1>Dieta<span class="branco">+Saúde</span></h1>
			<img class="logo_puc" src="img/puc_menu.png" alt="Sistema PUC">
		</div>

		<div id="area-menu">
        <a href="home.php">Página Inicial</a>
		</div>
		
	</div>	
<br>
<br>
	<div id="area-principal">
		<div id="area-postagens">
			
			<!-- abertura postagem-->
			<div class="postagem">
				<h2>DashBoard</h2>

			</div><!--// fechamento postagem-->


			</div><!--// fechamento postagem-->
       
		</div>

        <center>     <iframe title="Projeto POS - Página 1" width="1400" height="560.25" src="https://app.powerbi.com/reportEmbed?reportId=738876b6-093e-4647-b8ba-7e1a038b3981&autoAuth=true&ctid=94193a67-f514-46cc-b67a-f28fb92be6f1" frameborder="2" allowFullScreen="true"></iframe></center> 

<br>
<br>
		<div id="rodape">
			Todos os direitos reservados
		</div>

	</div>

	<script>
            const app = new Vue({
                el: '#app',
                data: {
                  errorproddesc: [],
                  proddesc: null,
                  errorkcal: [],
                  kcal: null,
                  errorquantidade: [],
                  quantidade: null,
                  errortipo: [],
                  tipo: null,
                  errorcafe: [],
                  cafe: null,
                },
                methods:{
                  checkForm: function (e) {
                    if (this.proddesc && this.kcal && this.quantidade && this.tipo && this.cafe) {
                      return true;
                    }
                    
                    this.errorproddesc = [];
    
                    if (!this.proddesc) {
                      this.errorproddesc.push('A Descrição do Produto é obrigatória.');
                    }

                    this.errorkcal = [];
    
                    if (!this.kcal) {
                   this.errorkcal.push('A Caloria do Produto é obrigatória.');
                    }

    
                    this.errorquantidade = [];
    
                    if (!this.quantidade) {
                      this.errorquantidade.push('A quantidade do Produto é obrigatória.');
                    }
    
                    this.errortipo= [];
    
                    if (!this.tipo) {
                      this.errortipo.push('O Tipo do Produto é obrigatório.');
                    }
    
                    this.errorcafe = [];
    
                    if (!this.cafe) {
                      this.errorcafe.push('Obrigatório informar se o produto pode ser consumido no café.');
                    }
                    
                    e.preventDefault();
                  }
                }
              })

			      
			  $("#cpfcnpj").keydown(function(){
            try {
                $("#cpfcnpj").unmask();
            } catch (e) {}
        
            var tamanho = $("#cpfcnpj").val().length;
        
            if(tamanho < 11){
                $("#cpfcnpj").mask("999.999.999-99");
            } else {
                $("#cpfcnpj").mask("99.999.999/9999-99");
            }

			var elem = this;
            setTimeout(function(){
                // mudo a posição do seletor
                elem.selectionStart = elem.selectionEnd = 10000;
            }, 0);
            // reaplico o valor para mudar o foco
            var currentValue = $(this).val();
            $(this).val('');
            $(this).val(currentValue);
        });
        
		function ApenasLetras(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode <= 255) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };

    function ApenasNumeros(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) )
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function ApenasNumerosPonto(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 47 && charCode < 58) || (charCode > 45 && charCode <= 47))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificaEmail(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 63 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode > 44 && charCode < 47) || (charCode > 94 && charCode < 96))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    
    function verificaComplemento(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 122) || (charCode > 47 && charCode < 58) || (charCode = 32 && charCode <= 32))
                return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    function verificasenha(e, t) {
        try {
            if (window.event) {
                var charCode = window.event.keyCode;
            } else if (e) {
                var charCode = e.which;
            } else {
                return true;
            }
            if ((charCode > 32 && charCode < 34) || (charCode > 34 && charCode < 39) || (charCode > 47 && charCode < 58) || (charCode > 62 && charCode < 91) || (charCode > 96 && charCode < 122))
            return true;
            else
                return false;
        } catch (err) {
            alert(err.Description);
        };
    };
    
    /*UTILIZANDO O ENTER COMO BOTÃO - JQUERY */
    $(document).ready(function() {
    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
        var self = $(this)
                , form = self.parents('form:eq(0)')
                , focusable
                , next
                ;
        if (e.keyCode == 13) {
            focusable = form.find('input,a,select,button,textarea').filter(':visible');
            next = focusable.eq(focusable.index(this) + 1);
            if (next.length) {
                next.focus();
            } else {
                form.salvar();
            }
            return false;
        }
    });
});
    
    </script>
    
    

</body>
</html>