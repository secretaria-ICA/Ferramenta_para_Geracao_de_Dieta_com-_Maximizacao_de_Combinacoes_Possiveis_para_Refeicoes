-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: dieta
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbcliente`
--

DROP TABLE IF EXISTS `tbcliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbcliente` (
  `nome` varchar(60) NOT NULL,
  `cpf` bigint NOT NULL,
  `peso` decimal(5,2) NOT NULL,
  `altura` decimal(4,2) NOT NULL,
  `telefone` varchar(12) NOT NULL,
  `endereco` varchar(30) NOT NULL,
  `rua` int NOT NULL,
  `email` varchar(70) NOT NULL,
  `cep` int NOT NULL,
  `imc` decimal(5,2) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `pesoideal` decimal(5,2) NOT NULL,
  PRIMARY KEY (`cpf`),
  KEY `idx_tbcliente_cpfcnpj` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbcliente`
--

LOCK TABLES `tbcliente` WRITE;
/*!40000 ALTER TABLE `tbcliente` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbcliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbdietacli`
--

DROP TABLE IF EXISTS `tbdietacli`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbdietacli` (
  `nome` varchar(60) NOT NULL,
  `cpf` bigint NOT NULL,
  `peso` decimal(5,2) NOT NULL,
  `consulta` int NOT NULL,
  `nconsulta` int NOT NULL,
  `id` bigint NOT NULL,
  `item` varchar(50) NOT NULL,
  `kcal` decimal(5,2) NOT NULL,
  `QtdPorcao` varchar(50) NOT NULL,
  `categoria` varchar(15) NOT NULL,
  `Refeicao` varchar(20) NOT NULL,
  `dia` varchar(15) NOT NULL,
  `datagerada` varchar(10) NOT NULL,
  KEY `idx_tbdietacli_cpf` (`cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbdietacli`
--

LOCK TABLES `tbdietacli` WRITE;
/*!40000 ALTER TABLE `tbdietacli` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbdietacli` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbproduto`
--

DROP TABLE IF EXISTS `tbproduto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbproduto` (
  `codigo` mediumint NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) NOT NULL,
  `kcal` decimal(7,2) NOT NULL,
  `quantidade` varchar(30) NOT NULL,
  `categoria` varchar(15) NOT NULL,
  `cafe` bit(1) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbproduto`
--

LOCK TABLES `tbproduto` WRITE;
/*!40000 ALTER TABLE `tbproduto` DISABLE KEYS */;
INSERT INTO `tbproduto` VALUES (1,'Nada',0.00,'0g','Vazio',_binary ''),(2,'Acém',859.00,'1 bife (310g)','Proteína',_binary ''),(3,'Asa de frango',77.00,'1 asa (29g)','Proteína',_binary ''),(4,'Asa de peru',53.00,'1 asa (24g)','Proteína',_binary '\0'),(5,'Avestruz',123.00,'1 porção (85g)','Proteína',_binary ''),(6,'Bife de peru',321.00,'1 bife (170g)','Proteína',_binary '\0'),(7,'Bife de porco',517.00,'1 bife (264g)','Proteína',_binary '\0'),(8,'Bisteca',238.00,'100g','Proteína',_binary '\0'),(9,'Cabidela / Miúdos de frango',229.00,'1 xícara (145g)','Proteína',_binary ''),(10,'Capa de filé / Entrecort',345.00,'1 bife (252g)','Proteína',_binary '\0'),(11,'Carne assada',721.00,'1 assado (515g)','Proteína',_binary '\0'),(12,'Carne de frango',344.00,'1 peito (200g)','Proteína',_binary ''),(13,'Carne moída / Guisado',172.00,'1 pedaço (70g)','Proteína',_binary ''),(14,'Carne seca',82.00,'1 pedaço (20g)','Proteína',_binary ''),(15,'Chester',305.00,'1 pedaço (150g)','Proteína',_binary ''),(16,'Chuleta',580.00,'1 bife (287g)','Proteína',_binary ''),(17,'Coração de frango',171.00,'1 porção (112g)','Proteína',_binary '\0'),(18,'Cordeiro',390.00,'1 pedaço (193g)','Proteína',_binary '\0'),(19,'Costela de vaca / Costela bovina',536.00,'1 pedaço (225g)','Proteína',_binary '\0'),(20,'Costela de porco',148.00,'1 costela (70g)','Proteína',_binary '\0'),(21,'Costeletas de porco',257.00,'1 pedaço (131g)','Proteína',_binary '\0'),(22,'Coxa de frango',346.00,'1 perna (199g)','Proteína',_binary '\0'),(23,'Coxão mole',430.00,'1 bife (236g)','Proteína',_binary '\0'),(24,'Escalope',203.00,'1 escalope (130g)','Proteína',_binary '\0'),(25,'Filé mignon',278.00,'1 file (104g)','Proteína',_binary '\0'),(26,'Fraldinha',365.00,'1 bife (188 g)','Proteína',_binary '\0'),(27,'Frango',731.00,'1/2 frango (334g)','Proteína',_binary '\0'),(28,'Figado de frango',73.00,'1 figado (44g)','Proteína',_binary '\0'),(29,'Jacaré',355.00,'1 porção (153g)','Proteína',_binary '\0'),(30,'Linguiça toscana',107.00,'1 pedaço (50g)','Proteína',_binary '\0'),(31,'Lombo bovino',305.00,'1 bife (40g)','Proteína',_binary '\0'),(32,'Lombo de porco',169.00,'1 pedaço (83g)','Proteína',_binary '\0'),(33,'Moela de frango',212.00,'1 xícara (145g)','Proteína',_binary '\0'),(34,'Ovelha',562.00,'1 pedaço (240g)','Proteína',_binary '\0'),(35,'Pato',337.00,'100g','Proteína',_binary '\0'),(36,'Peito bovino',242.00,'100g','Proteína',_binary '\0'),(37,'Peito de frango',344.00,'1 peito (200g)','Proteína',_binary '\0'),(38,'Peito de peru',1166.00,'1/2 peito (864g)','Proteína',_binary '\0'),(39,'Pernas / Coxa de peru',1136.00,'1 perna (546g)','Proteína',_binary '\0'),(40,'Peru',189.00,'100g','Proteína',_binary '\0'),(41,'Porco',363.00,'1 pedaço (185g)','Proteína',_binary '\0'),(42,'Porco assado',254.00,'100g','Proteína',_binary '\0'),(43,'Presunto',236.00,'1 fatia (145g)','Proteína',_binary '\0'),(44,'Ripa de costela',376.00,'1 porção (113g)','Proteína',_binary '\0'),(45,'Tiras de carne',328.00,'1 porção (165g)','Proteína',_binary '\0'),(46,'Vaca / Gado',407.00,'1 bife (164g)','Proteína',_binary '\0'),(47,'Arroz',80.00,'2 colheres de sopa','Carboidrato',_binary '\0'),(48,'Feijao preto',140.00,'1 concha média (120g)','Carboidrato',_binary '\0'),(49,'Pão francês',135.00,'1 unidade','Carboidrato',_binary ''),(50,'Pão integral',232.00,'100g','Carboidrato',_binary ''),(51,'Tapioca',356.00,'100g','Carboidrato',_binary ''),(52,'Cereais',378.00,'100g','Carboidrato',_binary ''),(53,'Massa',350.00,'100g','Carboidrato',_binary ''),(54,'Batata inglesa',60.00,'100g','Carboidrato',_binary '\0'),(55,'Batata doce',90.00,'100g','Carboidrato',_binary ''),(56,'Aipim',159.00,'100g','Carboidrato',_binary ''),(57,'Inhame',118.00,'100g','Carboidrato',_binary ''),(58,'Grao-de-bico',25.00,'2 colheres de sopa','Carboidrato',_binary ''),(59,'Lentilha',325.00,'100g','Carboidrato',_binary ''),(60,'Abobora',15.00,'100g','Carboidrato',_binary '\0'),(61,'Milho',363.00,'100g','Carboidrato',_binary ''),(62,'Pipoca',448.00,'100g','Carboidrato',_binary '\0'),(63,'Biscoito maisena',205.00,'10 unidades','Carboidrato',_binary ''),(64,'Farinha de milho',374.00,'100g','Carboidrato',_binary '\0'),(65,'Farinha de trigo',360.00,'100g','Carboidrato',_binary '\0'),(66,'Farinha de centeio integral',336.00,'100g','Carboidrato',_binary '\0'),(67,'Torrada integral',373.00,'100g','Carboidrato',_binary ''),(68,'Bolacha tipo cream cracker',442.00,'100g','Carboidrato',_binary ''),(69,'Aveia em flocos',394.00,'100g','Carboidrato',_binary ''),(70,'Ervilhas cozidas',72.00,'100g','Carboidrato',_binary '\0'),(71,'Soja cozida',151.00,'100g','Carboidrato',_binary '\0'),(72,'Mel',304.00,'100g','Carboidrato',_binary ''),(73,'Bolo',502.00,'100g','Carboidrato',_binary ''),(74,'Abobrinha italiana',17.00,'100g','Vegetais',_binary '\0'),(75,'Aboboa de pescoço',14.00,'100g','Vegetais',_binary '\0'),(76,'Acelga',19.00,'100g','Vegetais',_binary '\0'),(77,'Aipim / Mandioca',148.00,'100g','Vegetais',_binary '\0'),(78,'Aipo',16.00,'100g','Vegetais',_binary '\0'),(79,'Alcachofra',47.00,'100g','Vegetais',_binary '\0'),(80,'Alface',15.00,'100g','Vegetais',_binary ''),(81,'Alga nori',35.00,'100g','Vegetais',_binary '\0'),(82,'Alho',149.00,'100g','Vegetais',_binary '\0'),(83,'Alho-poro',61.00,'100g','Vegetais',_binary '\0'),(84,'Aspargo',20.00,'100g','Vegetais',_binary '\0'),(85,'Azeitona preta',115.00,'100g','Vegetais',_binary '\0'),(86,'Azeitonas',115.00,'100g','Vegetais',_binary '\0'),(87,'Azeitonas verdes',115.00,'100g','Vegetais',_binary '\0'),(88,'Batata',77.00,'100g','Vegetais',_binary '\0'),(89,'Batata doce',86.00,'100g','Vegetais',_binary '\0'),(90,'Beringela',25.00,'100g','Vegetais',_binary '\0'),(91,'Beterraba',43.00,'100g','Vegetais',_binary '\0'),(92,'Brócolis',34.00,'100g','Vegetais',_binary '\0'),(93,'Cebola',40.00,'100g','Vegetais',_binary '\0'),(94,'Cebolinha',30.00,'100g','Vegetais',_binary '\0'),(95,'Cebolinha verde',32.00,'100g','Vegetais',_binary '\0'),(96,'Cenoura',41.00,'100g','Vegetais',_binary ''),(97,'Chalotas',72.00,'100g','Vegetais',_binary '\0'),(98,'Cherovia',75.00,'100g','Vegetais',_binary '\0'),(99,'Chicória',72.00,'100g','Vegetais',_binary '\0'),(100,'Chuchu',19.00,'100g','Vegetais',_binary '\0'),(101,'Cogumelos / Champignon',22.00,'100g','Vegetais',_binary '\0'),(102,'Couve chinesa',16.00,'100g','Vegetais',_binary '\0'),(103,'Couve-de-folhas',49.00,'100g','Vegetais',_binary '\0'),(104,'Couve-flor',25.00,'100g','Vegetais',_binary '\0'),(105,'Couve-manteiga',32.00,'100g','Vegetais',_binary '\0'),(106,'Couve-nabo',38.00,'100g','Vegetais',_binary '\0'),(107,'Couve-rábano',27.00,'100g','Vegetais',_binary '\0'),(108,'Couves de bruxelas',43.00,'100g','Vegetais',_binary '\0'),(109,'Creme de espinafr',74.00,'100g','Vegetais',_binary '\0'),(110,'Endívia / Escarola',17.00,'100g','Vegetais',_binary '\0'),(111,'Erva-doce',31.00,'100g','Vegetais',_binary '\0'),(112,'Ervilhas',81.00,'100g','Vegetais',_binary '\0'),(113,'Espinafre',23.00,'100g','Vegetais',_binary '\0'),(114,'Folhas de mostarda',27.00,'100g','Vegetais',_binary '\0'),(115,'Folhas de nabo',20.00,'100g','Vegetais',_binary '\0'),(116,'Milho',365.00,'100g','Vegetais',_binary '\0'),(117,'Moranga',26.00,'100g','Vegetais',_binary '\0'),(118,'Nabo',28.00,'100g','Vegetais',_binary '\0'),(119,'Pepino',16.00,'100g','Vegetais',_binary '\0'),(120,'Pepino em conserva',14.00,'100g','Vegetais',_binary '\0'),(121,'Pimentão',27.00,'100g','Vegetais',_binary '\0'),(122,'Quiabo',33.00,'100g','Vegetais',_binary '\0'),(123,'Rabanetes',33.00,'100g','Vegetais',_binary '\0'),(124,'Raiz-forte',48.00,'100g','Vegetais',_binary '\0'),(125,'Repolho',25.00,'100g','Vegetais',_binary '\0'),(126,'Repolho-roxo',31.00,'100g','Vegetais',_binary '\0'),(127,'Rúcula',25.00,'100g','Vegetais',_binary '\0'),(128,'Tomate',18.00,'100g','Vegetais',_binary ''),(129,'Tomate-cereja',100.00,'100g','Vegetais',_binary '\0'),(130,'Vagem',31.00,'100g','Vegetais',_binary '\0'),(131,'Wasabi',109.00,'100g','Vegetais',_binary '\0'),(132,'Acerola',32.00,'100g','Frutas',_binary ''),(133,'Ameixa verde',41.00,'100g','Frutas',_binary ''),(134,'Azeitona',115.00,'100g','Frutas',_binary ''),(135,'Fisalis',49.00,'100g','Frutas',_binary ''),(136,'Cerejas',50.00,'100g','Frutas',_binary ''),(137,'Tamarindo',239.00,'100g','Frutas',_binary ''),(138,'Lichia',66.00,'100g','Frutas',_binary ''),(139,'Pitanga',40.00,'100g','Frutas',_binary ''),(140,'Rambutão',82.00,'100g','Frutas',_binary ''),(141,'Ruibarbo',21.00,'100g','Frutas',_binary ''),(142,'Damasco',48.00,'100g','Frutas',_binary ''),(143,'Limão',29.00,'100g','Frutas',_binary ''),(144,'Maracujá',97.00,'100g','Frutas',_binary ''),(145,'Lima',30.00,'100g','Frutas',_binary ''),(146,'Tâmara',282.00,'100g','Frutas',_binary ''),(147,'Cajá',46.00,'100g','Frutas',_binary ''),(148,'Melão cantaloupe',34.00,'100g','Frutas',_binary ''),(149,'Carambola',31.00,'100g','Frutas',_binary ''),(150,'Ameixa',46.00,'100g','Frutas',_binary ''),(151,'Caqui',127.00,'100g','Frutas',_binary ''),(152,'Tangerina murcote',47.00,'100g','Frutas',_binary ''),(153,'Figo',74.00,'100g','Frutas',_binary ''),(154,'Goiaba',68.00,'100g','Frutas',_binary ''),(155,'Jabuticaba',58.00,'100g','Frutas',_binary ''),(156,'Cranberries / Oxicoco',46.00,'100g','Frutas',_binary ''),(157,'Tangerina',53.00,'100g','Frutas',_binary ''),(158,'Morangos',32.00,'100g','Frutas',_binary ''),(159,'Marmelo',57.00,'100g','Frutas',_binary ''),(160,'Caju',553.00,'100g','Frutas',_binary ''),(161,'Pêssego',39.00,'100g','Frutas',_binary ''),(162,'Amora branca',43.00,'100g','Frutas',_binary ''),(163,'Amoras',43.00,'100g','Frutas',_binary ''),(164,'Laranja',47.00,'100g','Frutas',_binary ''),(165,'Groselha',56.00,'100g','Frutas',_binary ''),(166,'Framboesa',52.00,'100g','Frutas',_binary ''),(167,'Nectarina',44.00,'100g','Frutas',_binary ''),(168,'Laranja sanguínea / Laranja vermelha',50.00,'100g','Frutas',_binary ''),(169,'Mirtilos',57.00,'100g','Frutas',_binary ''),(170,'Melancia',30.00,'100g','Frutas',_binary ''),(171,'Maçã',52.00,'100g','Frutas',_binary ''),(172,'Pera',57.00,'100g','Frutas',_binary ''),(173,'Açai',70.00,'100g','Frutas',_binary ''),(174,'Uva',69.00,'100g','Frutas',_binary ''),(175,'Banana',89.00,'100g','Frutas',_binary ''),(176,'Kiwi',61.00,'100g','Frutas',_binary ''),(177,'Salada de frutas',50.00,'100g','Frutas',_binary ''),(178,'Jaca',95.00,'100g','Frutas',_binary ''),(179,'Purê de maçã',68.00,'100g','Frutas',_binary ''),(180,'Fruta do conde',101.00,'100g','Frutas',_binary ''),(181,'Manga',60.00,'100g','Frutas',_binary ''),(182,'Mamão',43.00,'100g','Frutas',_binary ''),(183,'Banana da terra',122.00,'100g','Frutas',_binary ''),(184,'Romã',83.00,'100g','Frutas',_binary ''),(185,'Coco',358.00,'100g','Frutas',_binary ''),(186,'Abacate',160.00,'100g','Frutas',_binary ''),(187,'Graviola',360.00,'100g','Frutas',_binary ''),(188,'Passa de uva / Uva-passa',299.00,'100g','Frutas',_binary ''),(189,'Abacaxi',50.00,'100g','Frutas',_binary '');
/*!40000 ALTER TABLE `tbproduto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbregdiasdieta`
--

DROP TABLE IF EXISTS `tbregdiasdieta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbregdiasdieta` (
  `idSequencial` mediumint NOT NULL AUTO_INCREMENT,
  `id` int DEFAULT NULL,
  `item` varchar(60) DEFAULT NULL,
  `kcal` float(10,2) DEFAULT NULL,
  `QtdPorcao` varchar(30) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL,
  `PermCafe` bit(1) DEFAULT NULL,
  `Random` float(30,30) DEFAULT NULL,
  `IdRandom` int DEFAULT NULL,
  `Refeicao` varchar(30) DEFAULT NULL,
  `OrderRef` int DEFAULT NULL,
  `dia` int DEFAULT NULL,
  `dataGrav` datetime DEFAULT NULL,
  PRIMARY KEY (`idSequencial`)
) ENGINE=InnoDB AUTO_INCREMENT=7507 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbregdiasdieta`
--

LOCK TABLES `tbregdiasdieta` WRITE;
/*!40000 ALTER TABLE `tbregdiasdieta` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbregdiasdieta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbtempdiasdieta`
--

DROP TABLE IF EXISTS `tbtempdiasdieta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbtempdiasdieta` (
  `id` int DEFAULT NULL,
  `item` varchar(60) DEFAULT NULL,
  `kcal` float(10,2) DEFAULT NULL,
  `QtdPorcao` varchar(30) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL,
  `PermCafe` bit(1) DEFAULT NULL,
  `Random` float(30,30) DEFAULT NULL,
  `IdRandom` int DEFAULT NULL,
  `Refeicao` varchar(30) DEFAULT NULL,
  `OrderRef` int DEFAULT NULL,
  `dia` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbtempdiasdieta`
--

LOCK TABLES `tbtempdiasdieta` WRITE;
/*!40000 ALTER TABLE `tbtempdiasdieta` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbtempdiasdieta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbtempgeradieta`
--

DROP TABLE IF EXISTS `tbtempgeradieta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbtempgeradieta` (
  `id` int DEFAULT NULL,
  `item` varchar(60) DEFAULT NULL,
  `kcal` float(10,2) DEFAULT NULL,
  `QtdPorcao` varchar(30) DEFAULT NULL,
  `categoria` varchar(30) DEFAULT NULL,
  `PermCafe` bit(1) DEFAULT NULL,
  `Random` float(30,30) DEFAULT NULL,
  `IdRandom` int DEFAULT NULL,
  `Refeicao` varchar(30) DEFAULT NULL,
  `OrderRef` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbtempgeradieta`
--

LOCK TABLES `tbtempgeradieta` WRITE;
/*!40000 ALTER TABLE `tbtempgeradieta` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbtempgeradieta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbtempseqdias`
--

DROP TABLE IF EXISTS `tbtempseqdias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbtempseqdias` (
  `dia` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbtempseqdias`
--

LOCK TABLES `tbtempseqdias` WRITE;
/*!40000 ALTER TABLE `tbtempseqdias` DISABLE KEYS */;
INSERT INTO `tbtempseqdias` VALUES (1);
/*!40000 ALTER TABLE `tbtempseqdias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbusuario`
--

DROP TABLE IF EXISTS `tbusuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbusuario` (
  `matricula` int DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `senha` varchar(80) DEFAULT NULL,
  `perfil` int DEFAULT NULL,
  `ativo` bit(1) DEFAULT NULL,
  KEY `idx_tbusuario_matricula` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbusuario`
--

LOCK TABLES `tbusuario` WRITE;
/*!40000 ALTER TABLE `tbusuario` DISABLE KEYS */;
INSERT INTO `tbusuario` VALUES (1,'Máurion Lourenço','202cb962ac59075b964b07152d234b70',1,_binary '');
/*!40000 ALTER TABLE `tbusuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-25 18:49:01
